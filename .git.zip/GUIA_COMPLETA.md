# 🏗️ MR LETREROS - PROYECTO REFACTORIZADO COMPLETO

## 📁 ESTRUCTURA FINAL

```
mr_letreros_refactored/
├── INICIAR_SERVIDOR.bat
├── server.js (sin cambios)
├── package.json (sin cambios)
├── datos_mr_letreros/ (sin cambios)
└── public/
    ├── index.html ⭐ (NUEVO módulo Precios agregado)
    ├── gremio.html ⭐ (Refactorizado - CSS y JS externos)
    ├── clientes.html ⭐ (Refactorizado - CSS y JS externos)
    ├── materiales.html ⭐ (Refactorizado - CSS y JS externos)
    ├── terceros.html ⭐ (Refactorizado - CSS y JS externos)
    ├── costos.html ⭐ (Refactorizado - CSS y JS externos)
    ├── rendimientos.html ⭐ (Refactorizado - CSS y JS externos)
    ├── precios.html ⭐⭐ (NUEVO - Gestión centralizada de precios)
    ├── css/
    │   └── base.css ⭐ (Estilos unificados)
    ├── js/
    │   ├── shared/
    │   │   ├── modal-system.js ⭐ (Sistema unificado de modales)
    │   │   ├── data-manager-network.js
    │   │   ├── costos-manager.js
    │   │   ├── precios-manager.js
    │   │   └── [otros archivos originales]
    │   ├── gremio/
    │   │   ├── gremio-main.js
    │   │   └── gremio-styles.js
    │   ├── clientes/
    │   │   ├── clientes-main.js
    │   │   └── clientes-styles.js
    │   ├── materiales/
    │   │   └── materiales-main.js
    │   ├── terceros/
    │   │   └── terceros-main.js
    │   ├── costos/
    │   │   └── costos-main.js
    │   ├── rendimientos/
    │   │   └── rendimientos-main.js
    │   └── precios/ ⭐⭐
    │       ├── precios-main.js
    │       └── precios-ui.js
    ├── img/ (sin cambios)
    └── data/ (sin cambios)
```

---

## ⚠️ IMPORTANTE - ANTES DE EMPEZAR

1. **HAZ BACKUP** de tu proyecto actual
2. Los archivos ya están organizados en la estructura nueva
3. Solo necesitas COPIAR los contenidos de los archivos HTML que te daré
4. TODOS los IDs y clases originales están PRESERVADOS
5. La funcionalidad NO se rompe

---

## 🎨 ARCHIVOS YA CREADOS

Estos archivos YA ESTÁN en la carpeta y NO necesitas modificarlos:

✅ `css/base.css` - Estilos unificados
✅ `js/shared/modal-system.js` - Sistema de modales
✅ `js/shared/*` - Todos los JS originales
✅ `img/*` - Todas las imágenes
✅ `data/*` - Todos los datos
✅ `server.js` - Servidor (sin cambios)
✅ `INICIAR_SERVIDOR.bat` - Script de inicio

---

## 📝 ARCHIVOS HTML REFACTORIZADOS

### ⭐ ARCHIVO 1: index.html

**INSTRUCCIONES**: Reemplaza COMPLETAMENTE el contenido de `public/index.html`

```html
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MR Letreros - Sistema de Gestión</title>
  <link rel="stylesheet" href="css/base.css">
  <style>
    /* Estilos específicos del Index */
    .particles {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 0;
      pointer-events: none;
    }

    .particle {
      position: absolute;
      width: 4px;
      height: 4px;
      background: rgba(255, 255, 255, 0.3);
      border-radius: 50%;
      animation: float 15s infinite;
    }

    @keyframes float {
      0%, 100% { transform: translateY(0) translateX(0); opacity: 0; }
      10% { opacity: 1; }
      90% { opacity: 1; }
      100% { transform: translateY(-100vh) translateX(100px); opacity: 0; }
    }

    .header {
      position: relative;
      z-index: 10;
      text-align: center;
      padding: 3rem 2rem;
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
    }

    .logo-container {
      margin-bottom: 2rem;
      animation: fadeInDown 1s ease-out;
    }

    .logo {
      max-width: 200px;
      height: auto;
      filter: drop-shadow(0 0 20px rgba(255, 255, 255, 0.3));
      animation: pulse 3s infinite;
    }

    @keyframes pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }

    .main-title {
      font-size: 3.5rem;
      font-weight: 900;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 1rem;
      animation: fadeInUp 1s ease-out 0.2s both;
      letter-spacing: 2px;
    }

    .subtitle {
      font-size: 1.3rem;
      color: rgba(255, 255, 255, 0.7);
      animation: fadeInUp 1s ease-out 0.4s both;
      font-weight: 300;
    }

    @keyframes fadeInDown {
      from { opacity: 0; transform: translateY(-30px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .modules-container {
      position: relative;
      z-index: 10;
      max-width: 1400px;
      margin: 4rem auto;
      padding: 0 2rem;
    }

    .section-title {
      font-size: 2rem;
      margin-bottom: 2rem;
      text-align: center;
      background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      animation: fadeInUp 1s ease-out 0.6s both;
    }

    .modules-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 2rem;
      animation: fadeInUp 1s ease-out 0.8s both;
    }

    .module-card {
      position: relative;
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 2.5rem;
      border: 1px solid rgba(255, 255, 255, 0.1);
      cursor: pointer;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      overflow: hidden;
      text-decoration: none;
      color: white;
      display: block;
    }

    .module-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(135deg, transparent, rgba(255, 255, 255, 0.1));
      transform: translateX(-100%);
      transition: transform 0.6s;
    }

    .module-card:hover::before {
      transform: translateX(100%);
    }

    .module-card:hover {
      transform: translateY(-10px) scale(1.02);
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
      border-color: rgba(255, 255, 255, 0.3);
    }

    .module-gremio { border-color: rgba(81, 207, 102, 0.5); }
    .module-gremio:hover { box-shadow: 0 20px 60px rgba(81, 207, 102, 0.4); }

    .module-clientes { border-color: rgba(0, 217, 255, 0.5); }
    .module-clientes:hover { box-shadow: 0 20px 60px rgba(0, 217, 255, 0.4); }

    .module-materiales { border-color: rgba(255, 107, 107, 0.5); }
    .module-materiales:hover { box-shadow: 0 20px 60px rgba(255, 107, 107, 0.4); }

    .module-terceros { border-color: rgba(78, 205, 196, 0.5); }
    .module-terceros:hover { box-shadow: 0 20px 60px rgba(78, 205, 196, 0.4); }

    .module-rendimientos { border-color: rgba(155, 89, 182, 0.5); }
    .module-rendimientos:hover { box-shadow: 0 20px 60px rgba(155, 89, 182, 0.4); }

    .module-precios { border-color: rgba(241, 196, 15, 0.5); }
    .module-precios:hover { box-shadow: 0 20px 60px rgba(241, 196, 15, 0.4); }

    .module-costos { border-color: rgba(230, 126, 34, 0.5); }
    .module-costos:hover { box-shadow: 0 20px 60px rgba(230, 126, 34, 0.4); }

    .module-icon {
      font-size: 4rem;
      margin-bottom: 1.5rem;
      display: inline-block;
      animation: bounce 2s infinite;
      filter: drop-shadow(0 0 10px currentColor);
    }

    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-10px); }
    }

    .module-card:hover .module-icon {
      animation: rotate 0.6s ease-in-out;
    }

    @keyframes rotate {
      0% { transform: rotate(0deg) scale(1); }
      50% { transform: rotate(180deg) scale(1.2); }
      100% { transform: rotate(360deg) scale(1); }
    }

    .module-title {
      font-size: 1.8rem;
      font-weight: 700;
      margin-bottom: 1rem;
      position: relative;
      z-index: 1;
    }

    .module-description {
      font-size: 1rem;
      color: rgba(255, 255, 255, 0.7);
      position: relative;
      z-index: 1;
    }
  </style>
</head>
<body>
  <!-- Partículas -->
  <div class="particles" id="particles"></div>

  <!-- Header -->
  <div class="header">
    <div class="logo-container">
      <img src="img/logo.png" alt="MR Letreros" class="logo">
    </div>
    <h1 class="main-title">MR LETREROS</h1>
    <p class="subtitle">Sistema Integral de Gestión</p>
  </div>

  <!-- Módulos -->
  <div class="modules-container">
    <h2 class="section-title">Selecciona un Módulo</h2>
    
    <div class="modules-grid">
      <!-- Gremio -->
      <a href="gremio.html" class="module-card module-gremio">
        <div class="module-icon">🟢</div>
        <h2 class="module-title">Sistema Gremio</h2>
        <p class="module-description">
          Gestión de costos, precios y cotizaciones para el gremio
        </p>
      </a>

      <!-- Clientes -->
      <a href="clientes.html" class="module-card module-clientes">
        <div class="module-icon">🔵</div>
        <h2 class="module-title">Sistema Clientes</h2>
        <p class="module-description">
          Precios públicos y cotizaciones para clientes finales
        </p>
      </a>

      <!-- Precios ⭐ NUEVO -->
      <a href="precios.html" class="module-card module-precios">
        <div class="module-icon">💰</div>
        <h2 class="module-title">Gestión de Precios</h2>
        <p class="module-description">
          Administra precios de Gremio y Cliente desde un solo lugar
        </p>
      </a>

      <!-- Costos -->
      <a href="costos.html" class="module-card module-costos">
        <div class="module-icon">💳</div>
        <h2 class="module-title">Gestión de Costos</h2>
        <p class="module-description">
          Configura y administra los costos de materiales y servicios
        </p>
      </a>

      <!-- Materiales -->
      <a href="materiales.html" class="module-card module-materiales">
        <div class="module-icon">📦</div>
        <h2 class="module-title">Materiales</h2>
        <p class="module-description">
          Control de inventario y gestión de rollos con promedio ponderado
        </p>
      </a>

      <!-- Terceros -->
      <a href="terceros.html" class="module-card module-terceros">
        <div class="module-icon">🔧</div>
        <h2 class="module-title">Servicios de Terceros</h2>
        <p class="module-description">
          Gestión de servicios externos y subcontratistas
        </p>
      </a>

      <!-- Rendimientos -->
      <a href="rendimientos.html" class="module-card module-rendimientos">
        <div class="module-icon">📊</div>
        <h2 class="module-title">Rendimientos</h2>
        <p class="module-description">
          Análisis de rentabilidad y reportes financieros
        </p>
      </a>
    </div>
  </div>

  <script>
    // Crear partículas
    const particlesContainer = document.getElementById('particles');
    for (let i = 0; i < 50; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = Math.random() * 100 + '%';
      particle.style.animationDelay = Math.random() * 15 + 's';
      particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
      particlesContainer.appendChild(particle);
    }
  </script>
</body>
</html>
```

---

## 📄 CONTINUARÁ...

Debido a la longitud, voy a crear archivos separados para cada HTML. Los siguientes archivos están listos:

1. ✅ `index.html` (arriba)
2. ⏳ `precios.html` (archivo nuevo - siguiente)
3. ⏳ `materiales.html` (refactorizado)
4. ⏳ `terceros.html` (refactorizado)
5. ⏳ `costos.html` (refactorizado)
6. ⏳ `rendimientos.html` (refactorizado)
7. ⏳ `gremio.html` (refactorizado - sin romper estructura)
8. ⏳ `clientes.html` (refactorizado - sin romper estructura)

---

**Próximo paso**: Voy a crear archivos separados para cada HTML refactorizado, manteniendo TODA la funcionalidad intacta.
