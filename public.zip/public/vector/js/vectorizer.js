/**
 * vectorizer.js - Lógica para la vectorización de imágenes y manipulación de mapas de bits.
 * Contiene las funciones para quitar fondo y vectorizar.
 */

/**
 * Elimina el fondo de una imagen usando IA en el navegador.
 * Es llamada por el event listener en app.js.
 */
async function handleRemoveBackground() {
    const removeBgBtn = document.getElementById('btnRemoveBg');
    const sourcePreviewImg = document.getElementById('sourcePreviewImg');
    const downloadPngBtn = document.getElementById('btnDownloadPng');
    const vectorizeBtn = document.getElementById('btnVectorize');

    if (!sourcePreviewImg.src || sourcePreviewImg.src.startsWith('data:image/svg')) {
        if (typeof showStatus === 'function') showStatus('Primero carga una imagen (JPG, PNG).', 'error');
        return;
    }

    // Deshabilitar botón y mostrar estado de carga
    removeBgBtn.disabled = true;
    removeBgBtn.innerHTML = '🪄 Procesando IA...';
    if (typeof showStatus === 'function') showStatus('Quitando fondo... (La primera vez puede tardar un poco)', 'loading');

    try {
        // Verificamos si la librería cargó correctamente
        if (typeof imglyRemoveBackground === 'undefined') {
            throw new Error("La librería de IA no se ha cargado. Revisa tu conexión a internet.");
        }

        // La función correcta de la librería es imglyRemoveBackground
        const blob = await imglyRemoveBackground(sourcePreviewImg.src);
        
        const url = URL.createObjectURL(blob);
        
        // Actualiza la vista previa para mostrar la imagen sin fondo.
        sourcePreviewImg.src = url;
        
        // Guardar en estado global (de globals.js)
        currentImgUrl = url;

        // --- NUEVO: Mostrar imagen sin fondo en el visor principal ---
        const sheetsContainer = document.getElementById('sheetsContainer');
        const statsBar = document.getElementById('statsBar');
        
        if (sheetsContainer) {
            sheetsContainer.innerHTML = '';
            const img = document.createElement('img');
            img.src = url;
            img.style.maxWidth = '100%';
            img.style.maxHeight = '500px';
            // Fondo de ajedrez para resaltar la transparencia
            img.style.background = 'conic-gradient(#eee 0.25turn, transparent 0.25turn 0.5turn, #eee 0.5turn 0.75turn, transparent 0.75turn) top left / 20px 20px repeat';
            img.style.border = '1px solid #555';
            sheetsContainer.appendChild(img);
        }
        if (statsBar) statsBar.innerText = "✨ Fondo eliminado. Listo para vectorizar.";
        // -------------------------------------------------------------

        if (typeof showStatus === 'function') showStatus('Fondo eliminado. Ahora puedes vectorizar.', 'success');
        
        // Habilitar y configurar el botón para descargar el PNG sin fondo.
        downloadPngBtn.style.display = 'block';
        vectorizeBtn.disabled = false; // Habilitar vectorización

    } catch (error) {
        console.error('Error al quitar el fondo:', error);
        if (typeof showStatus === 'function') showStatus('Error: ' + error.message, 'error');
    } finally {
        // Reactivar el botón al finalizar
        removeBgBtn.disabled = false;
        removeBgBtn.innerHTML = '🪄 Quitar Fondo';
    }
}

/**
 * Ejecuta la vectorización de la imagen de vista previa usando ImageTracer.js.
 * Es llamada por el event listener en app.js.
 */
function runVectorization() {
    const sourceImg = document.getElementById('sourcePreviewImg');
    if (!sourceImg.src || sourceImg.src.startsWith('data:image/svg')) {
        if (typeof showStatus === 'function') showStatus('Carga una imagen o quita el fondo primero.', 'error');
        return;
    }

    if (typeof showStatus === 'function') showStatus('📐 Vectorizando imagen...', 'loading');
    const vectorizeBtn = document.getElementById('btnVectorize');
    const nestBtn = document.getElementById('btnNest');
    const downloadSvgBtn = document.getElementById('btnDownloadSvg');

    vectorizeBtn.disabled = true;
    nestBtn.disabled = true;
    downloadSvgBtn.style.display = 'none';

    // 1. Obtener opciones de los sliders
    const options = {
        ltres: parseFloat(document.getElementById('smoothing').value),
        qtres: parseFloat(document.getElementById('smoothing').value),
        pathomit: parseInt(document.getElementById('noise').value),
        numberofcolors: parseInt(document.getElementById('colors').value),
        strokewidth: 1,
        viewbox: true,
        colorsampling: 2,
        blurradius: 0.5,
        blurdelta: 10
    };

    // 2. Usar ImageTracer.js (API con callback)
    ImageTracer.imageToSVG(
        sourceImg.src,
        async function(svgString) {
            // 3. Guardar y mostrar el SVG
            currentSvgString = svgString; // Variable global de globals.js
            displayFinalSvg(svgString);   // Función de app.js para mostrar el SVG principal
            
            // 4. Habilitar acciones siguientes
            downloadSvgBtn.style.display = 'block';
            nestBtn.disabled = false;
            vectorizeBtn.disabled = false;

            // 5. Analizar las piezas del nuevo SVG para el nesting (función de nester.js)
            await parseSvgParts(svgString, (current, total) => {
                 if (typeof showStatus === 'function') showStatus(`🧩 Analizando piezas: ${current}/${total}`, 'loading');
            });

            if (typeof showStatus === 'function') showStatus('✅ Piezas listas para acomodar.', 'success');
        },
        options
    );
}