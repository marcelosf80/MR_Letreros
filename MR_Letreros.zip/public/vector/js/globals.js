// Estado Global compartido entre módulos
var globalSvgImage = null;
var svgViewBox = { w: 0, h: 0 };
var globalParts = []; 
var currentSvgString = null; 
var currentImgUrl = null; 
var lastPacker = null;